CREATE TABLE "products" (
	"id" serial PRIMARY KEY,
	"name" text NOT NULL,
	"cat" text DEFAULT 'Прочее' NOT NULL,
	"price" real DEFAULT 0 NOT NULL,
	"cost" real DEFAULT 0 NOT NULL
);
--> statement-breakpoint
CREATE TABLE "sales" (
	"id" serial PRIMARY KEY,
	"name" text NOT NULL,
	"cat" text DEFAULT '' NOT NULL,
	"qty" real DEFAULT 1 NOT NULL,
	"price" real DEFAULT 0 NOT NULL,
	"sale_price" real DEFAULT 0 NOT NULL,
	"cost" real DEFAULT 0 NOT NULL,
	"profit" real DEFAULT 0 NOT NULL,
	"user" text DEFAULT '' NOT NULL,
	"ts" double precision NOT NULL
);
