import type { Config } from "@netlify/functions";
import { db } from "../../db/index.js";
import { sales } from "../../db/schema.js";
import { and, desc, eq, gte, lte } from "drizzle-orm";

export default async (req: Request) => {
  if (req.method === "GET") {
    const url = new URL(req.url);
    const dateStr = url.searchParams.get("date") ?? new Date().toISOString().slice(0, 10);
    const start = new Date(dateStr + "T00:00:00").getTime();
    const end = new Date(dateStr + "T23:59:59.999").getTime();

    const result = await db
      .select()
      .from(sales)
      .where(and(gte(sales.ts, start), lte(sales.ts, end)))
      .orderBy(desc(sales.ts));

    return Response.json(result);
  }

  if (req.method === "POST") {
    const body = await req.json();
    const [sale] = await db
      .insert(sales)
      .values({
        name: body.name,
        cat: body.cat ?? "",
        qty: body.qty ?? 1,
        price: body.price ?? 0,
        salePrice: body.salePrice ?? 0,
        cost: body.cost ?? 0,
        profit: body.profit ?? 0,
        user: body.user ?? "",
        ts: body.ts ?? Date.now(),
      })
      .returning();
    return Response.json(sale, { status: 201 });
  }

  if (req.method === "DELETE") {
    const url = new URL(req.url);
    const id = parseInt(url.searchParams.get("id") ?? "0");
    if (!id) return new Response("id is required", { status: 400 });
    await db.delete(sales).where(eq(sales.id, id));
    return new Response(null, { status: 204 });
  }

  return new Response("Method Not Allowed", { status: 405 });
};

export const config: Config = {
  path: "/api/sales",
};
