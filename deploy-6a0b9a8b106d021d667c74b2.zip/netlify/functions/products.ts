import type { Config } from "@netlify/functions";
import { db } from "../../db/index.js";
import { products } from "../../db/schema.js";
import { eq } from "drizzle-orm";

const DEF_PRODUCTS = [
  { name: "Видеорегистратор DVR-X200", cat: "Электроника", price: 3500, cost: 2200 },
  { name: "Видеорегистратор DVR-Pro", cat: "Электроника", price: 5200, cost: 3400 },
  { name: "Автомобильное зарядное USB", cat: "Электроника", price: 600, cost: 280 },
  { name: "Антирадар Cobra RX-7", cat: "Электроника", price: 3200, cost: 1900 },
  { name: "Парктроник 4 датчика", cat: "Электроника", price: 2800, cost: 1600 },
  { name: "Автомобильный освежитель", cat: "Аксессуары", price: 250, cost: 120 },
  { name: "Солнцезащитный козырёк", cat: "Аксессуары", price: 200, cost: 90 },
  { name: "Органайзер в багажник", cat: "Аксессуары", price: 900, cost: 450 },
  { name: "Чехлы на сиденья (комплект)", cat: "Интерьер", price: 4800, cost: 2900 },
  { name: "Коврики резиновые (4 шт)", cat: "Интерьер", price: 1200, cost: 650 },
  { name: "Накидка на руль кожаная", cat: "Интерьер", price: 800, cost: 400 },
  { name: "Дефлекторы окон (комплект)", cat: "Внешний тюнинг", price: 1500, cost: 850 },
  { name: "Спойлер универсальный", cat: "Внешний тюнинг", price: 3800, cost: 2200 },
  { name: "Автомобильная аптечка", cat: "Прочее", price: 350, cost: 150 },
  { name: "Огнетушитель автомобильный", cat: "Прочее", price: 600, cost: 300 },
];

export default async (req: Request) => {
  if (req.method === "GET") {
    let all = await db.select().from(products);
    if (all.length === 0) {
      await db.insert(products).values(DEF_PRODUCTS);
      all = await db.select().from(products);
    }
    return Response.json(all);
  }

  if (req.method === "POST") {
    const body = await req.json();
    if (!body.name) return new Response("name is required", { status: 400 });
    const [product] = await db
      .insert(products)
      .values({ name: body.name, cat: body.cat || "Прочее", price: body.price ?? 0, cost: body.cost ?? 0 })
      .returning();
    return Response.json(product, { status: 201 });
  }

  if (req.method === "DELETE") {
    const url = new URL(req.url);
    const id = parseInt(url.searchParams.get("id") ?? "0");
    if (!id) return new Response("id is required", { status: 400 });
    await db.delete(products).where(eq(products.id, id));
    return new Response(null, { status: 204 });
  }

  return new Response("Method Not Allowed", { status: 405 });
};

export const config: Config = {
  path: "/api/products",
};
