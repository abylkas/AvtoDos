import { pgTable, serial, text, real, doublePrecision } from "drizzle-orm/pg-core";

export const products = pgTable("products", {
  id: serial().primaryKey(),
  name: text().notNull(),
  cat: text().notNull().default("Прочее"),
  price: real().notNull().default(0),
  cost: real().notNull().default(0),
});

export const sales = pgTable("sales", {
  id: serial().primaryKey(),
  name: text().notNull(),
  cat: text().notNull().default(""),
  qty: real().notNull().default(1),
  price: real().notNull().default(0),
  salePrice: real("sale_price").notNull().default(0),
  cost: real().notNull().default(0),
  profit: real().notNull().default(0),
  user: text().notNull().default(""),
  ts: doublePrecision("ts").notNull(),
});
